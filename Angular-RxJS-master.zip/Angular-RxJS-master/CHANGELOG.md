#Changes made to the course since its release:
- February 22, 2022: Updated to RxJS 7 and Angular 13. See the [detailed list of changes here](https://docs.google.com/document/d/1Kv4j4hEk-7cPh3lWgZoxyewU1IvlNOSPHKuKYb689v0/edit?usp=sharing).

- July 9, 2020: Reviewed the code in the course for any changes required for v10. No code changes required.

- February 2, 2020: Reviewed the code in the course for any changes required for v9. No code changes required.

#Changes made to the project files since its release:
- February 22, 2022: Updated to RxJS 7 and Angular 13. See the [detailed list of changes here](https://docs.google.com/document/d/1Kv4j4hEk-7cPh3lWgZoxyewU1IvlNOSPHKuKYb689v0/edit?usp=sharing).

- July 9, 2020: Updated the code to Angular v10, which modified the packages. Minor changes such as adding function return types.

- February 2, 2020: Updated the code to Angular v9, which only modified the packages not any of the course code.