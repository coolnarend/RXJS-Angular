import { ChangeDetectionStrategy, Component } from '@angular/core';
import { catchError, EMPTY, Observable, of } from 'rxjs';

// import { Subscription } from 'rxjs';
import { ProductCategory } from '../product-categories/product-category';

import { Product } from './product';
import { ProductService } from './product.service';

@Component({
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductListComponent  {
  pageTitle = 'Product List';
  errorMessage = '';
  categories: ProductCategory[] = [];

  // products: Product[] = [];
  products$ = this.productService.products$
    .pipe(
      catchError(err => {
        this.errorMessage = err;
        // return of([]);
        return EMPTY;
      })
    );
  // sub!: Subscription;

  constructor(private productService: ProductService) { }
  

  // ngOnDestroy(): void {
  //   this.sub.unsubscribe();
  // }

  onAdd(): void {
    console.log('Not yet implemented');
  }

  onSelected(categoryId: string): void {
    console.log('Not yet implemented');
  }
}
